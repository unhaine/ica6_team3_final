export const useCollapsible = () => {
    return {}
}
