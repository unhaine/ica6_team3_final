export const collapsibleStyles = {}
