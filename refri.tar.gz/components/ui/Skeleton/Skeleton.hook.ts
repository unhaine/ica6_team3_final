export const useSkeleton = () => {
    return {}
}
